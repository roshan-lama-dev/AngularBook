import { Component } from '@angular/core';
import { BookData } from './BookData';
import { DataService } from './data.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  template: `<br /><br />

    <div class="title">
      <h1>Displaying the information of all the books</h1>
    </div>

    <div class="nav">
      <a routerLink="/second"> View the Book List </a> ||
      <a routerLink="/third"> Delete Book From the List with book_id</a>
      <a routerLink="/fourth"> Update book from the list</a>
      <a routerLink="/fifth"> Insert Book in the list</a>
    </div>

    <!-- To display the content -->
    <router-outlet></router-outlet>
    <br /><br />

    <style>
      .title {
        text-align: center;
        color: rebeccapurple;
      }

      .nav {
        display: flex;
        justify-content: center;
      }

      .nav > a {
        text-decoration: none;
        color: black
        font-size: large;
        margin-right: 15px;
      }
    </style>`,
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'AngularOnline';
  // For displaying the book
  allBooks: BookData[] = new Array();
  errorMessage: string = '';

  // For deleting the book by ID
  id_deleted: string = '';
  errorMessage2: string = '';

  id_updated: string = '';
  title_updated: string = '';
  errorMessage3: string = '';

  constructor(private dataService: DataService) {}
  getAllBooks() {
    this.dataService.getAllBooks().subscribe(
      (d: any) => {
        this.allBooks = d;
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'Cannot retrieve the data';
      }
    );
  }
}
